#include "factorial.h"
int factorial(const int aNumber){
	int res = 1;
	if (aNumber < 0)
		return -1;
	else{
		for(int i = 1; i <= aNumber;i++){
			res *= i;
		}
	}
	return res;

}
