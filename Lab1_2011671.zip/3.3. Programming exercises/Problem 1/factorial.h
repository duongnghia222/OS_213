
#ifndef FACTORIAL_H
#define FACTORIAL_H
	
int factorial(const int aNumber);
#endif
