#include <stdio.h>
#include "factorial.h"
int main(){
	int a = 5;
	printf("answer = %d\n", factorial(a));
	return 0;
}
