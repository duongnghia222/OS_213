#include "readline.h"
#include <stdio.h>
#include <stdlib.h>
int main(){
	char* str = malloc(255);
	printf("%d",read_line(str));
	free(str);
	return 0;
}
