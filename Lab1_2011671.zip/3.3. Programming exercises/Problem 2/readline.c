
#include "readline.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
int read_line(char *str){
	scanf("%255s", str);
	int len = strlen(str);
	for (int i =0; i< len; i++){
		if(str[i]<'0'||str[i]>'9'){
			return 0;
		}

	}
	return 1;
	
}
