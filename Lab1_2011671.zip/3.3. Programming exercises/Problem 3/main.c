#include "header_files/readline.h"
#include "header_files/factorial.h"
#include <stdio.h>
#include <stdlib.h>
int main(int argc, char * argv[]){
	char* str = malloc(50);
	while(read_line(str)==1)
       	{
		int num = atoi(str);
		printf("%d\n", factorial(num));	
	}
	printf("%d",-1);
	fflush(stdout);
	return 0;
}

