#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
	FILE *f;
	f = fopen("numbers.txt", "r");
	int arr[100];
	int num;
	int l = 0;
	while(!feof(f)) {
		fscanf(f, "%d", &num);
		arr[l++] = num;
	}
	
	pid_t pid = fork();
	int cnt1 = 0;
	int cnt2 = 0;
	if(pid > 0) {
		wait(0);
		for(int i = 0; i < l - 1; i++) {
			if(arr[i] % 2 == 0) {
				cnt1++;
				
			}
		}
		printf("%d\n", cnt1);
	}
	else if(pid == 0) {
		for(int i = 0; i < l - 1; i++) {
			if(arr[i] % 3 == 0) {
				cnt2++;
			}
		}
		printf("%d\n", cnt2);	
	}
	
	else {
		perror("Failed");
	}
	
	fclose(f);
	return 0;
}
