#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

float randNumGen(){
   int random_value = rand(); //Generate a random number   
   float unit_random = random_value / (float) RAND_MAX; //make it between 0 and 1 
   return unit_random;
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "usage: ./pi_serial <total points>\n");
        return -1;
    }

    srand(time(NULL));         //initiate random seed

    float in_count = 0;
    float tot_count = 0;
    int tot_iterations = atol(argv[1]);
    int counter = 0;
    
    for(counter = 0; counter < tot_iterations; counter++){
        float x = randNumGen();
        float y = randNumGen();
        
        float result = sqrt((x*x) + (y*y));
        
        if(result < 1){
            in_count += 1;         //check if the generated value is inside a unit circle
        }
        tot_count += 1; 
    }

    float pi = 4*in_count/tot_count;
    printf("PI = %f\n",pi);
}