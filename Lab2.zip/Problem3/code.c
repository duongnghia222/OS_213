#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<unistd.h>
void* hello(void* tid){
        int t = *(int*)tid;
        printf("Hello from thread %d\n",t);
        pthread_exit(0);
}
int main(){
        pthread_t tid[10];
        int i;
        for(i=0; i<10; i++){
            int* a =  malloc(sizeof(int));
            *a = i;
            pthread_create(&tid[i],NULL,hello,a);
            //sleep(0.100);
            pthread_join(tid[i],NULL); 
        }
        
        pthread_exit(NULL);
}