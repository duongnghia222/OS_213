#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>

#define MAX_ITEMS 2
#define THREADS 1 // 1 enroll and 1 disenroll
#define LOOPS 2*MAX_ITEMS // test case

// Initiate shared buffer

int buffer[MAX_ITEMS];
int fill = 0;
int use = 0;
int num = 0;  // number slots in buffer 
pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t c_enroll = PTHREAD_COND_INITIALIZER; 
pthread_cond_t c_disenroll = PTHREAD_COND_INITIALIZER; 

void put(int value); 
int get(); 
void *fenroll(void *arg){
    int i;
    int tid = *(int*)arg;
    for (i = 0; i < LOOPS; i++) {
        pthread_mutex_lock (&m);
		if (num > MAX_ITEMS) exit(1);
        while(num == MAX_ITEMS ){
            pthread_cond_wait (&c_enroll, &m);
        }
        put(i); 
        sleep (1);
        pthread_mutex_unlock (&m);
        pthread_cond_signal (&c_disenroll);
        printf("Enroll %d : student enrolled slot %d \n", tid, i);


    }  
    printf("enroll exited\n"); 
    pthread_exit(NULL);
}
void *fdisenroll(void *arg) {
    int i, tmp = 0;
    int tid = *(int*)arg;
    while (tmp !=  -1) {
        pthread_mutex_lock (&m);
        if (num < 0) exit(1);
        while(num == 0){
             pthread_cond_wait (&c_disenroll, &m);
        }
        tmp = get (); // line C2
        sleep(1);
        pthread_mutex_unlock (&m);
        pthread_cond_signal (&c_enroll);
        printf("Disenroll %d : student disenrolled slot %d\n", tid, tmp);

    }
    //printf("disenroll exited\n"); 
    // disenroll never exit

    pthread_exit (NULL);
}
int main(int argc, char sxargv){
    int i, j;
    //int tid[THREADS];
    pthread_t enroll[THREADS];
    pthread_t disenroll[THREADS];

    for(i = 0; i < THREADS; i++){
        int *a = malloc(sizeof(int));
        *a = i;
        // Create enroll thread
        pthread_create(&enroll[i], NULL, fenroll, a);
        // Create disenroll thread
        pthread_create(&disenroll [i], NULL, fdisenroll, a);
    }
    for(i = 0; i < THREADS; i++){
        pthread_join(enroll[i], NULL);
        pthread_join(disenroll[i], NULL);
    }   

    pthread_mutex_destroy(&m);
    pthread_cond_destroy(&c_enroll);
    pthread_cond_destroy(&c_disenroll);
    return 0;
}
void put(int value) {
    buffer[fill] = value; 
    fill = (fill + 1) % MAX_ITEMS;
    num++;
}
int get(){
    int tmp = buffer[use]; 
    use = (use + 1) % MAX_ITEMS; 
    num--;
    return tmp;
}