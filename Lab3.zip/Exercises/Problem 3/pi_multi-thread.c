#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#define THREADS 4

void *runner(void* arg) {
    int points_per_thread = *(int*)arg;
    int incircle_thread = 0;
    unsigned int rand_state = rand();
    int i;
    for (i = 0; i < points_per_thread; i++) {
        double x = rand_r(&rand_state) / ((double)RAND_MAX + 1) * 2.0 - 1.0;
        double y = rand_r(&rand_state) / ((double)RAND_MAX + 1) * 2.0 - 1.0;
        if (x * x + y * y < 1) {
            incircle_thread++;
        }
    }
    int* res = malloc(sizeof(int));
    *res = incircle_thread;
    return (void*)res;
}

int main(int argc, const char *argv[])
{
    pthread_t threads[THREADS];
    if (argc != 2) {
        fprintf(stderr, "misssing argument\n");
        return -1;
    }
    int incircle = 0;
    int* res;
    long totalpoints = atol(argv[1]);
    int points_per_thread = totalpoints / THREADS;
    int i;
    int* a = malloc(sizeof(int));
    *a = points_per_thread;
    for (i = 0; i < THREADS; i++) {
        pthread_create(&threads[i], NULL, runner, a);
    }
    
 for (i = 0; i < THREADS; i++) {
        pthread_join(threads[i], (void**)&res);
        incircle += *res;
    }
    printf("PI = %f\n", (4. * (double)incircle) / totalpoints);  
    free(a);
    return 0;
}
