#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include<semaphore.h>
#include <unistd.h>
#define THREADS 4
static sem_t piLock;
long incircle = 0;
long points_per_thread;
void *runner() {
    long incircle_thread = 0;
    unsigned int rand_state = rand();
    long i;
    for (i = 0; i < points_per_thread; i++) {
        double x = rand_r(&rand_state) / ((double)RAND_MAX + 1) * 2.0 - 1.0;
        double y = rand_r(&rand_state) / ((double)RAND_MAX + 1) * 2.0 - 1.0;
        if (x * x + y * y < 1) {
            incircle_thread++;
        }
    }
    sem_wait(&piLock);
    incircle += incircle_thread;
    sem_post(&piLock);
}
int main(int argc, const char *argv[])
{
    sem_init(&piLock, 0, THREADS);
    pthread_t threads[THREADS];
    if (argc != 2) {
        fprintf(stderr, "misssing argument\n");
        return -1;
    }   
    long totalpoints = atol(argv[1]);
    points_per_thread = totalpoints / THREADS;
    int i;
    for (i = 0; i < THREADS; i++) {
        pthread_create(&threads[i], NULL, runner, (void *) NULL);    
    }
    for (i = 0; i < THREADS; i++) {    
        pthread_join(threads[i], NULL);
    }
    sem_destroy(&piLock);
    printf("PI = %f\n", (4. * (double)incircle) / totalpoints);
    return 0;
}
